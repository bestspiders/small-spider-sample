#-*- coding:utf-8 -*-
import requests
from lxml import etree
import re
import os
import sys
from urllib import urlretrieve
def first_url(first_result):
	select_url = etree.HTML(first_result.content)
	new_url = select_url.xpath('//*[@id="thumbs2"]/li/a/img/@src')
	return new_url
def second_url(all_url):
	about_list = []
	for new_url in all_url:
		front_url = re.findall('.*net/(.*)240',new_url)
		behind_url = re.findall('.*240\.(.*.jpg)',new_url)
		will_url = 'http://static.zerochan.net/'+front_url[0]+'full.'+behind_url[0]
		about_list.append(will_url)
	return about_list
def no_results(first_result):#判断no results是否存在
	result = etree.HTML(first_result.content)
	select_url = result.xpath('//*[@id="content"]/p/text()')
	return select_url

def read_info():
    file = open('zerochancheck.txt','r+')
    result=[]
    for line in file.readlines():
        line=line.strip('\n')
        result.append(line)
    file.close()
    return result

def loop_content():
    file = open('zerochancheck.txt','a')
    file.write(second_url(all_url)[num]+'\n')
    file.close()

address=raw_input('please entry save address:')
necessary = raw_input('please entry web:')
s= requests.Session()
h=1
for k in range(0,100):
	url = necessary+str(k)
	first_result = s.get(url)
	all_url = first_url(first_result)
	if not 'No results' in no_results(first_result):
		if all_url:
			# if not os.path.exists(address+'\\'+str(k)):
			# 	os.mkdir(address+'\\'+str(k))
			long_url = len(second_url(all_url))
			for num in range(0,long_url):
				if second_url(all_url)[num] in read_info():
					h+=1
					pass
				else:
					urlretrieve(second_url(all_url)[num],address+'\\'+str(h)+'.jpg')
					h+=1
					loop_content()
					print 'successful save'+str(num)
		else:
			pass
	else:
		break